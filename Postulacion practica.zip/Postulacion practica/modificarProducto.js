guardarButton.addEventListener("click", () => {
    
    const nuevoNombre = nombreInput.value;
    const nuevaDescripcion = descripcionInput.value;
    const nuevoPrecio = precioInput.value;
    const productoId = document.getElementById("producto_id").value;
  
})