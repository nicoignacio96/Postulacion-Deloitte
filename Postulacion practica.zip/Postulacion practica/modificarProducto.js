// Dentro de la función modificarProducto
guardarButton.addEventListener("click", () => {
    // Obtener los datos modificados del formulario
    const nuevoNombre = nombreInput.value;
    const nuevaDescripcion = descripcionInput.value;
    const nuevoPrecio = precioInput.value;
    const productoId = document.getElementById("producto_id").value;
  
})